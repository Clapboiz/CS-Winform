﻿namespace Bai05
{
    partial class Bai5
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            button1 = new Button();
            button2 = new Button();
            button3 = new Button();
            button4 = new Button();
            button5 = new Button();
            button6 = new Button();
            button7 = new Button();
            button8 = new Button();
            button9 = new Button();
            button10 = new Button();
            button11 = new Button();
            button12 = new Button();
            button13 = new Button();
            button14 = new Button();
            button15 = new Button();
            button16 = new Button();
            button17 = new Button();
            button18 = new Button();
            Hienthi1 = new TextBox();
            Hienthi2 = new TextBox();
            button19 = new Button();
            button20 = new Button();
            button21 = new Button();
            button22 = new Button();
            button23 = new Button();
            button24 = new Button();
            button25 = new Button();
            button26 = new Button();
            button27 = new Button();
            button28 = new Button();
            button29 = new Button();
            button30 = new Button();
            button31 = new Button();
            button32 = new Button();
            button33 = new Button();
            button34 = new Button();
            button35 = new Button();
            button36 = new Button();
            SuspendLayout();
            // 
            // button1
            // 
            button1.Location = new Point(258, 198);
            button1.Name = "button1";
            button1.Size = new Size(94, 29);
            button1.TabIndex = 0;
            button1.Text = "7";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // button2
            // 
            button2.Location = new Point(371, 198);
            button2.Name = "button2";
            button2.Size = new Size(94, 29);
            button2.TabIndex = 1;
            button2.Text = "8";
            button2.UseVisualStyleBackColor = true;
            button2.Click += button2_Click;
            // 
            // button3
            // 
            button3.Location = new Point(483, 198);
            button3.Name = "button3";
            button3.Size = new Size(94, 29);
            button3.TabIndex = 2;
            button3.Text = "9";
            button3.UseVisualStyleBackColor = true;
            button3.Click += button3_Click;
            // 
            // button4
            // 
            button4.Location = new Point(594, 198);
            button4.Name = "button4";
            button4.Size = new Size(94, 29);
            button4.TabIndex = 3;
            button4.Text = "+";
            button4.UseVisualStyleBackColor = true;
            button4.Click += button4_Click;
            // 
            // button5
            // 
            button5.Location = new Point(594, 233);
            button5.Name = "button5";
            button5.Size = new Size(94, 29);
            button5.TabIndex = 7;
            button5.Text = "-";
            button5.UseVisualStyleBackColor = true;
            button5.Click += button5_Click;
            // 
            // button6
            // 
            button6.Location = new Point(483, 233);
            button6.Name = "button6";
            button6.Size = new Size(94, 29);
            button6.TabIndex = 6;
            button6.Text = "6";
            button6.UseVisualStyleBackColor = true;
            button6.Click += button6_Click;
            // 
            // button7
            // 
            button7.Location = new Point(371, 233);
            button7.Name = "button7";
            button7.Size = new Size(94, 29);
            button7.TabIndex = 5;
            button7.Text = "5";
            button7.UseVisualStyleBackColor = true;
            button7.Click += button7_Click;
            // 
            // button8
            // 
            button8.Location = new Point(258, 233);
            button8.Name = "button8";
            button8.Size = new Size(94, 29);
            button8.TabIndex = 4;
            button8.Text = "4";
            button8.UseVisualStyleBackColor = true;
            button8.Click += button8_Click;
            // 
            // button9
            // 
            button9.Location = new Point(594, 268);
            button9.Name = "button9";
            button9.Size = new Size(94, 29);
            button9.TabIndex = 11;
            button9.Text = "*";
            button9.UseVisualStyleBackColor = true;
            button9.Click += button9_Click;
            // 
            // button10
            // 
            button10.Location = new Point(483, 268);
            button10.Name = "button10";
            button10.Size = new Size(94, 29);
            button10.TabIndex = 10;
            button10.Text = "3";
            button10.UseVisualStyleBackColor = true;
            button10.Click += button10_Click;
            // 
            // button11
            // 
            button11.Location = new Point(371, 268);
            button11.Name = "button11";
            button11.Size = new Size(94, 29);
            button11.TabIndex = 9;
            button11.Text = "2";
            button11.UseVisualStyleBackColor = true;
            button11.Click += button11_Click;
            // 
            // button12
            // 
            button12.Location = new Point(258, 268);
            button12.Name = "button12";
            button12.Size = new Size(94, 29);
            button12.TabIndex = 8;
            button12.Text = "1";
            button12.UseVisualStyleBackColor = true;
            button12.Click += button12_Click;
            // 
            // button13
            // 
            button13.Location = new Point(594, 303);
            button13.Name = "button13";
            button13.Size = new Size(94, 29);
            button13.TabIndex = 15;
            button13.Text = "/";
            button13.UseVisualStyleBackColor = true;
            button13.Click += button13_Click;
            // 
            // button14
            // 
            button14.Location = new Point(483, 303);
            button14.Name = "button14";
            button14.Size = new Size(94, 29);
            button14.TabIndex = 14;
            button14.Text = "=";
            button14.UseVisualStyleBackColor = true;
            button14.Click += button14_Click;
            // 
            // button15
            // 
            button15.Location = new Point(371, 303);
            button15.Name = "button15";
            button15.Size = new Size(94, 29);
            button15.TabIndex = 13;
            button15.Text = ".";
            button15.UseVisualStyleBackColor = true;
            button15.Click += button15_Click;
            // 
            // button16
            // 
            button16.Location = new Point(258, 303);
            button16.Name = "button16";
            button16.Size = new Size(94, 29);
            button16.TabIndex = 12;
            button16.Text = "0";
            button16.UseVisualStyleBackColor = true;
            button16.Click += button16_Click;
            // 
            // button17
            // 
            button17.Location = new Point(594, 163);
            button17.Name = "button17";
            button17.Size = new Size(94, 29);
            button17.TabIndex = 19;
            button17.Text = "CE";
            button17.UseVisualStyleBackColor = true;
            button17.Click += button17_Click;
            // 
            // button18
            // 
            button18.Location = new Point(483, 163);
            button18.Name = "button18";
            button18.Size = new Size(94, 29);
            button18.TabIndex = 18;
            button18.Text = "C";
            button18.UseVisualStyleBackColor = true;
            button18.Click += button18_Click;
            // 
            // Hienthi1
            // 
            Hienthi1.Location = new Point(369, 122);
            Hienthi1.Multiline = true;
            Hienthi1.Name = "Hienthi1";
            Hienthi1.Size = new Size(319, 30);
            Hienthi1.TabIndex = 20;
            Hienthi1.TextChanged += Hienthi1_TextChanged;
            // 
            // Hienthi2
            // 
            Hienthi2.Location = new Point(369, 94);
            Hienthi2.Multiline = true;
            Hienthi2.Name = "Hienthi2";
            Hienthi2.Size = new Size(319, 26);
            Hienthi2.TabIndex = 21;
            Hienthi2.TextChanged += textBox1_TextChanged;
            // 
            // button19
            // 
            button19.Location = new Point(258, 161);
            button19.Name = "button19";
            button19.Size = new Size(94, 29);
            button19.TabIndex = 22;
            button19.Text = "x^2";
            button19.UseVisualStyleBackColor = true;
            button19.Click += button19_Click;
            // 
            // button20
            // 
            button20.Location = new Point(371, 161);
            button20.Name = "button20";
            button20.Size = new Size(94, 29);
            button20.TabIndex = 23;
            button20.Text = "x^y";
            button20.UseVisualStyleBackColor = true;
            button20.Click += button20_Click;
            // 
            // button21
            // 
            button21.Location = new Point(158, 198);
            button21.Name = "button21";
            button21.Size = new Size(94, 29);
            button21.TabIndex = 24;
            button21.Text = "sin";
            button21.UseVisualStyleBackColor = true;
            button21.Click += button21_Click;
            // 
            // button22
            // 
            button22.Location = new Point(158, 233);
            button22.Name = "button22";
            button22.Size = new Size(94, 29);
            button22.TabIndex = 25;
            button22.Text = "cos";
            button22.UseVisualStyleBackColor = true;
            button22.Click += button22_Click;
            // 
            // button23
            // 
            button23.Location = new Point(158, 268);
            button23.Name = "button23";
            button23.Size = new Size(94, 29);
            button23.TabIndex = 26;
            button23.Text = "tan";
            button23.UseVisualStyleBackColor = true;
            button23.Click += button23_Click;
            // 
            // button24
            // 
            button24.Location = new Point(158, 161);
            button24.Name = "button24";
            button24.Size = new Size(94, 29);
            button24.TabIndex = 27;
            button24.Text = "Căn 2";
            button24.UseVisualStyleBackColor = true;
            button24.Click += button24_Click;
            // 
            // button25
            // 
            button25.Location = new Point(258, 126);
            button25.Name = "button25";
            button25.Size = new Size(94, 29);
            button25.TabIndex = 28;
            button25.Text = "10^x";
            button25.UseVisualStyleBackColor = true;
            button25.Click += button25_Click;
            // 
            // button26
            // 
            button26.Location = new Point(258, 91);
            button26.Name = "button26";
            button26.Size = new Size(94, 29);
            button26.TabIndex = 29;
            button26.Text = "log";
            button26.UseVisualStyleBackColor = true;
            button26.Click += button26_Click;
            // 
            // button27
            // 
            button27.Location = new Point(58, 91);
            button27.Name = "button27";
            button27.Size = new Size(94, 29);
            button27.TabIndex = 30;
            button27.Text = "exp";
            button27.UseVisualStyleBackColor = true;
            button27.Click += button27_Click;
            // 
            // button28
            // 
            button28.Location = new Point(158, 126);
            button28.Name = "button28";
            button28.Size = new Size(94, 29);
            button28.TabIndex = 31;
            button28.Text = "mod";
            button28.UseVisualStyleBackColor = true;
            button28.Click += button28_Click;
            // 
            // button29
            // 
            button29.Location = new Point(158, 91);
            button29.Name = "button29";
            button29.Size = new Size(94, 29);
            button29.TabIndex = 32;
            button29.Text = "n!";
            button29.UseVisualStyleBackColor = true;
            button29.Click += button29_Click;
            // 
            // button30
            // 
            button30.Location = new Point(158, 303);
            button30.Name = "button30";
            button30.Size = new Size(94, 29);
            button30.TabIndex = 33;
            button30.Text = ")";
            button30.UseVisualStyleBackColor = true;
            button30.Click += button30_Click;
            // 
            // button31
            // 
            button31.Location = new Point(58, 303);
            button31.Name = "button31";
            button31.Size = new Size(94, 29);
            button31.TabIndex = 34;
            button31.Text = "(";
            button31.UseVisualStyleBackColor = true;
            button31.Click += button31_Click;
            // 
            // button32
            // 
            button32.Location = new Point(58, 268);
            button32.Name = "button32";
            button32.Size = new Size(94, 29);
            button32.TabIndex = 35;
            button32.Text = "pi";
            button32.UseVisualStyleBackColor = true;
            button32.Click += button32_Click;
            // 
            // button33
            // 
            button33.Location = new Point(58, 161);
            button33.Name = "button33";
            button33.Size = new Size(94, 29);
            button33.TabIndex = 36;
            button33.Text = "M+";
            button33.UseVisualStyleBackColor = true;
            button33.Click += button33_Click;
            // 
            // button34
            // 
            button34.Location = new Point(58, 198);
            button34.Name = "button34";
            button34.Size = new Size(94, 29);
            button34.TabIndex = 37;
            button34.Text = "M-";
            button34.UseVisualStyleBackColor = true;
            button34.Click += button34_Click;
            // 
            // button35
            // 
            button35.Location = new Point(58, 126);
            button35.Name = "button35";
            button35.Size = new Size(94, 29);
            button35.TabIndex = 38;
            button35.Text = "MS";
            button35.UseVisualStyleBackColor = true;
            button35.Click += button35_Click;
            // 
            // button36
            // 
            button36.Location = new Point(58, 233);
            button36.Name = "button36";
            button36.Size = new Size(94, 29);
            button36.TabIndex = 39;
            button36.Text = "+/-";
            button36.UseVisualStyleBackColor = true;
            button36.Click += button36_Click;
            // 
            // Bai5
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(button36);
            Controls.Add(button35);
            Controls.Add(button34);
            Controls.Add(button33);
            Controls.Add(button32);
            Controls.Add(button31);
            Controls.Add(button30);
            Controls.Add(button29);
            Controls.Add(button28);
            Controls.Add(button27);
            Controls.Add(button26);
            Controls.Add(button25);
            Controls.Add(button24);
            Controls.Add(button23);
            Controls.Add(button22);
            Controls.Add(button21);
            Controls.Add(button20);
            Controls.Add(button19);
            Controls.Add(Hienthi2);
            Controls.Add(Hienthi1);
            Controls.Add(button17);
            Controls.Add(button18);
            Controls.Add(button13);
            Controls.Add(button14);
            Controls.Add(button15);
            Controls.Add(button16);
            Controls.Add(button9);
            Controls.Add(button10);
            Controls.Add(button11);
            Controls.Add(button12);
            Controls.Add(button5);
            Controls.Add(button6);
            Controls.Add(button7);
            Controls.Add(button8);
            Controls.Add(button4);
            Controls.Add(button3);
            Controls.Add(button2);
            Controls.Add(button1);
            Name = "Bai5";
            Text = "Bai5";
            Load += Form1_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button button1;
        private Button button2;
        private Button button3;
        private Button button4;
        private Button button5;
        private Button button6;
        private Button button7;
        private Button button8;
        private Button button9;
        private Button button10;
        private Button button11;
        private Button button12;
        private Button button13;
        private Button button14;
        private Button button15;
        private Button button16;
        private Button button17;
        private Button button18;
        private TextBox Hienthi1;
        private TextBox Hienthi2;
        private Button button19;
        private Button button20;
        private Button button21;
        private Button button22;
        private Button button23;
        private Button button24;
        private Button button25;
        private Button button26;
        private Button button27;
        private Button button28;
        private Button button29;
        private Button button30;
        private Button button31;
        private Button button32;
        private Button button33;
        private Button button34;
        private Button button35;
        private Button button36;
    }
}