﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Sakk_Alkalmazás_2._0
{
    public partial class ClickUserClass : UserControl
    {
        public int pozX;
        public int pozY;

        public ClickUserClass()
        {
            InitializeComponent();
        }
    }
}
