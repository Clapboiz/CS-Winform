# WindowsFormChess
 
Classic C# chess game made with Windows Form Application Where you can play alone or with your friend if you are on the same network.

## Lan
One of the player have to click the "Host" button and the other one have to click to the "Connection" button after he wrote the Ip address of the Host.

To get your Ip address write "ipconfig" into cmd.
